package com.boot.security.server.controller;

import org.junit.Test;

import static org.junit.Assert.*;


public class DictControllerTest {

    @Test
    public void get() {
    }
}