package com.boot.security.server.model;

public class Dict extends BaseEntity<Long> {

	private static final long serialVersionUID = -2431140186410912787L;
	private String type;
	private String k;
	private String val;

	public String getType() {
		return type;
	}

	public String setType() {
		return type;
	}

	public String getK() {
		return k;
	}

	public String setK() {
		return k;
	}

	public String getVal() {
		return val;
	}

	public String setVal() {
		return val;
	}

}
